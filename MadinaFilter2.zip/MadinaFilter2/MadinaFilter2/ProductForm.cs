﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MadinaFilter2
{
    public partial class ProductForm : Form
    {
        public ProductForm()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            this.Hide();
            LoginForm login = new LoginForm();
            login.Show();
        }

        private void btnhome_Click(object sender, EventArgs e)
        {
            this.Hide();
            HomeForm Home = new HomeForm();
            Home.Show();
        }
        
        private void btnclear_Click(object sender, EventArgs e)
        {
            txtFilterName.Text = "";
            txtQuantity.Text = "";
            textFilterPrice.Text = "";
            comboBrand.Text = "";
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (txtFilterName.Text == "" && txtQuantity.Text == "" && textFilterPrice.Text == "" && comboBrand.Text == "")
            {
                MessageBox.Show("Please Filled All Colomns", "Stop", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else if (txtFilterName.Text == "" && txtQuantity.Text == "" && textFilterPrice.Text == "")
            {
                MessageBox.Show("Please Enter Filter Name And Filter Quantity And Filter Price", "Stop", MessageBoxButtons.OK, MessageBoxIcon.Information);
                comboBrand.Text = "";
            }
            else if (txtFilterName.Text == "" && txtQuantity.Text == "" && comboBrand.Text == "")
            {
                MessageBox.Show("Please Enter Filter Name And Filter Quantity And Select Brand Of Filter  ", "Stop", MessageBoxButtons.OK, MessageBoxIcon.Information);
                textFilterPrice.Text = "";
            }
            else if (txtFilterName.Text == "" && textFilterPrice.Text == "" && comboBrand.Text == "")
            {
                MessageBox.Show("Please Enter Filter Name And Filter Price And Select Brand Of Filter", "Stop", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtQuantity.Text = "";
            }
            else if (txtQuantity.Text == "" && textFilterPrice.Text == "" && comboBrand.Text == "")
            {
                MessageBox.Show("Please Enter Filter Quantity And Filter Price And Select Brand Of Filter", "Stop", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtFilterName.Text = "";
            }
            else if (txtFilterName.Text == "" && txtQuantity.Text == "")
            {
                MessageBox.Show("Please Enter Filter Name And Filter Quantity", "Stop", MessageBoxButtons.OK, MessageBoxIcon.Information);
                comboBrand.Text = "";
                textFilterPrice.Text = "";
            }
            else if (txtFilterName.Text == "" && textFilterPrice.Text == "")
            {
                MessageBox.Show("Please Enter Filter Name And Filter Price", "Stop", MessageBoxButtons.OK, MessageBoxIcon.Information);
                comboBrand.Text = "";
                txtQuantity.Text = "";
            }
            else if (txtFilterName.Text == "" && comboBrand.Text == "")
            {
                MessageBox.Show("Please Enter Filter Name And Select Brand Of Filter", "Stop", MessageBoxButtons.OK, MessageBoxIcon.Information);
                textFilterPrice.Text = "";
                txtQuantity.Text = "";
            }
            else if (txtQuantity.Text == "" && textFilterPrice.Text == "")
            {
                MessageBox.Show("Please Enter Filter Quantity And Filter Price", "Stop", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtFilterName.Text = "";
                comboBrand.Text = "";
            }
            else if (txtQuantity.Text == "" && comboBrand.Text == "")
            {
                MessageBox.Show("Please Enter Filter Quantity And  Select Brand Of Filter", "Stop", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtFilterName.Text = "";
                textFilterPrice.Text = "";
            }
            else if (textFilterPrice.Text == "" && comboBrand.Text == "")
            {
                MessageBox.Show("Please Enter Filter Price And  Select Brand Of Filter", "Stop", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtFilterName.Text = "";
                txtQuantity.Text = "";
            }
            else if (txtFilterName.Text == "")
            {
                MessageBox.Show("Please Enter Filter Name ", "Stop", MessageBoxButtons.OK, MessageBoxIcon.Information);
                textFilterPrice.Text = "";
                txtQuantity.Text = "";
                comboBrand.Text = "";
            }
            else if (txtQuantity.Text == "")
            {
                MessageBox.Show("Please Enter Filter Quantity ", "Stop", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtFilterName.Text = "";
                textFilterPrice.Text = "";
                comboBrand.Text = "";
            }
            else if (textFilterPrice.Text == "")
            {
                MessageBox.Show("Please Enter Filter Price ", "Stop", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtFilterName.Text = "";
                txtQuantity.Text = "";
                comboBrand.Text = "";
            }
            else if (comboBrand.Text == "")
            {
                MessageBox.Show("Please Select Brand Of Filter ", "Stop", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtFilterName.Text = "";
                txtQuantity.Text = "";
                textFilterPrice.Text = "";
            }
            else
            {
                OleDbConnection my_con = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=MadinaFilter2 .accdb");
                my_con.Open();
                OleDbCommand command = new OleDbCommand("Insert into Producttbl (FilterName,Quantity,Brand,FilterPrice) Values('" + txtFilterName.Text + "','" + txtQuantity.Text + "','" + comboBrand.SelectedItem.ToString() + "','" + textFilterPrice.Text + "')", my_con);
                command.ExecuteNonQuery();

                my_con.Close();
                MessageBox.Show("Your Product Successfully Added", "Congrats", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                txtFilterName.Text = "";
                txtQuantity.Text = "";
                textFilterPrice.Text = "";
                comboBrand.Text = "";
            }
        }
    }
}
