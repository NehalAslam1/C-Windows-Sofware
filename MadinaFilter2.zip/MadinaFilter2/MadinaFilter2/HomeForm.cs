﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MadinaFilter2
{
    public partial class HomeForm : Form
    {
        public HomeForm()
        {
            InitializeComponent();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            this.Hide();
            LoginForm login = new LoginForm();
            login.Show();
        }

        private void btnProductform_Click(object sender, EventArgs e)
        {
            this.Hide();
            ProductForm product = new ProductForm();
            product.Show();
        }

        private void btnviewstock_Click(object sender, EventArgs e)
        {
            this.Hide();
            ViewStock stock = new ViewStock();
            stock.Show();
        }

        private void btnSelling_Click(object sender, EventArgs e)
        {
            this.Hide();
            SellingForm Selling = new SellingForm();
            Selling.Show();

        }
       
    }
}
