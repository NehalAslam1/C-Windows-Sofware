﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MadinaFilter2
{
    public partial class SellingForm : Form
    {
        int oldQuantity = 0;
        int newQuantity = 0;
        int BillID, Quantity, FilterPrice, TotalBillAmount, Pos = 60;
        string FilterName, BillDate;
        int grdTotal = 0;

        public SellingForm()
        {
            InitializeComponent();
        }

        private void SellingForm_Load(object sender, EventArgs e)
        {
            SelectProduct();
            SelectBill();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnlogout_Click(object sender, EventArgs e)
        {
            this.Hide();
            LoginForm login = new LoginForm();
            login.Show();
        }

        private void ProductGridView_SelectionChanged(object sender, EventArgs e)
        {
            if (ProductGridView.SelectedRows.Count != 0)
            {
                DataGridViewRow row = ProductGridView.SelectedRows[0];
                txtFilterName.Text = row.Cells["FilterName"].Value.ToString();
                //txtQuantity.Text = row.Cells["Quantity"].Value.ToString();
                txtFilterPrice.Text = row.Cells["FilterPrice"].Value.ToString();
                txtFilterID.Text = row.Cells["FilterID"].Value.ToString();
                oldQuantity = Convert.ToInt32(row.Cells["Quantity"].Value.ToString());
                newQuantity = Convert.ToInt32(row.Cells["Quantity"].Value.ToString());
            }
        }

        private void btnaddtobill_Click(object sender, EventArgs e)
        {
            if (txtQuantity.Text == "" || Convert.ToInt32(txtQuantity.Text) > oldQuantity)
            {
                MessageBox.Show("Not Enough Stock", "Stop", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                Clear();
            }
            else if (txtFilterName.Text == "" && txtFilterPrice.Text == "" && txtQuantity.Text == "" && txtTotalBillAmount.Text == "")
            {
                MessageBox.Show("Please Filled All Coloumns", "Stop", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else
            {
                newQuantity = oldQuantity - Convert.ToInt32(txtQuantity.Text);
                OleDbConnection my_con = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=MadinaFilter2 .accdb");
                my_con.Open();
                OleDbCommand command = new OleDbCommand("Insert into BillTbl (FilterName,Quantity,FilterPrice,BillDate,TotalBillAmount) Values('" + txtFilterName.Text + "'," + Convert.ToInt32(txtQuantity.Text) + "," + Convert.ToInt32(txtFilterPrice.Text) + ",'" + txtBillDate.Text + "'," + Convert.ToInt32(txtTotalBillAmount.Text) + ")", my_con);
                OleDbCommand Command = new OleDbCommand("Update Producttbl Set Quantity = " + newQuantity + " where FilterID = " + txtFilterID.Text, my_con);

                command.ExecuteNonQuery();
                Command.ExecuteNonQuery();

                my_con.Close();
                SelectProduct();
                MessageBox.Show("Your Product Successfully Added", "Congrats", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                SelectBill();
            }
        }

        private void txtQuantity_TextChanged(object sender, EventArgs e)
        {
            if (txtQuantity.Text != "")
            {
                txtTotalBillAmount.Text = (Convert.ToInt32(txtQuantity.Text) * Convert.ToInt32(txtFilterPrice.Text)).ToString();
            }
            else
            {
                txtTotalBillAmount.Text = "0";
            }
        }

        public void SelectBill()
        {

            OleDbConnection my_con = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=MadinaFilter2 .accdb");
            my_con.Open();
            OleDbCommand command = new OleDbCommand("Select * from BillTbl", my_con);
            command.ExecuteNonQuery();

            DataTable dt = new DataTable();
            OleDbDataAdapter oleDbDataAdapter = new OleDbDataAdapter(command);

            oleDbDataAdapter.Fill(dt);

            BillGridView.DataSource = dt;

            my_con.Close();
            int sum = 0;
            for (int i = 0; i < BillGridView.Rows.Count; i++)
            {
                sum += Convert.ToInt32(BillGridView.Rows[i].Cells["TotalBillAmount"].Value);
                grdTotal = sum;
            }
        }
        

    public void SelectProduct()
        {

            OleDbConnection my_con = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=MadinaFilter2 .accdb");
            my_con.Open();
            OleDbCommand command = new OleDbCommand("Select * from Producttbl", my_con);
            command.ExecuteNonQuery();

            DataTable dt = new DataTable();
            OleDbDataAdapter oleDbDataAdapter = new OleDbDataAdapter(command);

            oleDbDataAdapter.Fill(dt);

            ProductGridView.DataSource = dt;

            my_con.Close();
        }
       
    public void Clear()
        {
            txtFilterName.Text = "";
            txtQuantity.Text = "";
            txtFilterPrice.Text = "";
            txtTotalBillAmount.Text = "";
            txtFilterID.Text = "";
        }

        private void btnClearBill_Click(object sender, EventArgs e)
        {
            OleDbConnection my_con = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=MadinaFilter2 .accdb");
            my_con.Open();

            OleDbCommand command = new OleDbCommand("Delete From BillTbl where BillID", my_con);

            command.ExecuteNonQuery();

            my_con.Close();
            SelectBill();
            MessageBox.Show("Your Bill Successfully Clear", "Congrats", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
        }
        

    private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            e.Graphics.DrawString("Madina Vehicle Filter Work Shop", new Font("Century Gothic", 14, FontStyle.Bold), Brushes.Red, new Point(160));
            e.Graphics.DrawString("ID       Date                                  FilterName              Quantity     FilterPrice       TotalBill", new Font("Century Gothic", 10, FontStyle.Bold), Brushes.Red, new Point(26, 40));
            foreach (DataGridViewRow row in BillGridView.Rows)
            {
                BillID = Convert.ToInt32(row.Cells["BillID"].Value);
                BillDate = "" + row.Cells["BillDate"].Value;
                FilterName = "" + row.Cells["FilterName"].Value;
                Quantity = Convert.ToInt32(row.Cells["Quantity"].Value);
                FilterPrice = Convert.ToInt32(row.Cells["FilterPrice"].Value);
                TotalBillAmount = Convert.ToInt32(row.Cells["TotalBillAmount"].Value);
                e.Graphics.DrawString("" + BillID, new Font("Century Gothic", 8, FontStyle.Bold), Brushes.Blue, new Point(24, Pos));
                e.Graphics.DrawString("" + BillDate, new Font("Century Gothic", 8, FontStyle.Bold), Brushes.Blue, new Point(67, Pos));
                e.Graphics.DrawString("" + FilterName, new Font("Century Gothic", 8, FontStyle.Bold), Brushes.Blue, new Point(230, Pos));
                e.Graphics.DrawString("" + Quantity, new Font("Century Gothic", 8, FontStyle.Bold), Brushes.Blue, new Point(382, Pos));
                e.Graphics.DrawString("" + FilterPrice, new Font("Century Gothic", 8, FontStyle.Bold), Brushes.Blue, new Point(455, Pos));
                e.Graphics.DrawString("" + TotalBillAmount, new Font("Century Gothic", 8, FontStyle.Bold), Brushes.Blue, new Point(540, Pos));
                Pos = Pos + 20;
            }
            e.Graphics.DrawString("Grand Total : RS  " + grdTotal , new Font("Century Gothic", 12, FontStyle.Bold), Brushes.Crimson, new Point(230, Pos + 50));
            e.Graphics.DrawString(" ******************************** THANK YOU ********************************", new Font("Century Gothic", 12, FontStyle.Bold), Brushes.Crimson, new Point(10, Pos + 85));
            //BillGridView.Rows.Clear();
            //BillGridView.Refresh();
            // Pos = 100;
            //GrdTotal = 0;
        }
       
        private void btnPrint_Click(object sender, EventArgs e)
        {
            printDocument1.DefaultPageSettings.PaperSize = new System.Drawing.Printing.PaperSize("pprnm", 600, 600);
            if (printPreviewDialog1.ShowDialog() == DialogResult.OK)
            {
                printDocument1.Print();
            }
            
        }
    }
}
