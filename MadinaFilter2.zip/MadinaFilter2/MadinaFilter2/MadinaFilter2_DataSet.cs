﻿namespace MadinaFilter2
{


    public partial class MadinaFilter2_DataSet
    {
    }
}
