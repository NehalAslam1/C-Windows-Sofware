﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MadinaFilter2
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == false)
                txtPassword.UseSystemPasswordChar = true;
            else
                txtPassword.UseSystemPasswordChar = false;

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            OleDbConnection my_con = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=MadinaFilter2 .accdb");
            my_con.Open();
            OleDbCommand command = new OleDbCommand("Select * from Usertbl where UserName = '" + txtUserName.Text + "' AND UserPassword = '" + txtPassword.Text + "'", my_con);
            //            OleDbCommand command = new OleDbCommand("Select * from Usertbl where UserName = 'Nedfdhal' AND UserPassword = 'ffdfd'", my_con);
            command.ExecuteNonQuery();
            my_con.Close();

            if (txtUserName.Text == "" && txtPassword.Text == "")
            {
                MessageBox.Show("Please Enter UserName and Password.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (txtUserName.Text == "")
            {
                MessageBox.Show("Please Enter UserName", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (txtPassword.Text == "")
            {
                MessageBox.Show("Please Enter Password", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                DataTable dt = new DataTable();
                OleDbDataAdapter reader = new OleDbDataAdapter(command);
                reader.Fill(dt);
                if (dt.Rows.Count == 0)
                {
                    MessageBox.Show("Invalid UserName or Password", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtUserName.Text = "";
                    txtPassword.Text = "";
                }
                else
                {
                    this.Hide();

                    HomeForm homepage = new HomeForm();
                    homepage.Show();
                    my_con.Close();
                }
            }
        }

        private void btnSignUp_Click(object sender, EventArgs e)
        {
            this.Hide();
            SignupForm signup = new SignupForm();
            signup.Show();
        }

        private void LoginForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'madinaFilter2_DataSet.Usertbl' table. You can move, or remove it, as needed.
            this.usertblTableAdapter.Fill(this.madinaFilter2_DataSet.Usertbl);

        }
    }
}
