﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MadinaFilter2
{
    public partial class ViewStock : Form
    {
        public ViewStock()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            this.Hide();
            HomeForm Home = new HomeForm();
            Home.Show();
        }

        private void btnlogout_Click(object sender, EventArgs e)
        {
            this.Hide();
            LoginForm login = new LoginForm();
            login.Show();
        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            txtFilterName.Text = "";
            txtQuantity.Text = "";
            textFilterPrice.Text = "";
            comboBrand.Text = "";
            txtFilterID.Text = "";
        }

        private void ViewStock_Load(object sender, EventArgs e)
        {
            SelectProduct();
        }

        public void SelectProduct()
        {

            OleDbConnection my_con = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=MadinaFilter2 .accdb");
            my_con.Open();
            OleDbCommand command = new OleDbCommand("Select * from Producttbl", my_con);
            command.ExecuteNonQuery();

            DataTable dt = new DataTable();
            OleDbDataAdapter oleDbDataAdapter = new OleDbDataAdapter(command);

            oleDbDataAdapter.Fill(dt);

            ProductGridView.DataSource = dt;

            my_con.Close();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (txtFilterID.Text == "" && txtFilterName.Text == "" && txtQuantity.Text == "" && textFilterPrice.Text == "" && comboBrand.Text == "") 
            {
                MessageBox.Show("Please select A row for Edit", "Stop", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                OleDbConnection my_con = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=MadinaFilter2 .accdb");
                my_con.Open();

                OleDbCommand cmd = new OleDbCommand("Update Producttbl Set FilterName = '" + txtFilterName.Text + "', Quantity = '" + txtQuantity.Text + "', Brand = '" + comboBrand.SelectedItem.ToString() + "', FilterPrice = '" + textFilterPrice.Text + "' where FilterID = " + txtFilterID.Text, my_con);

                cmd.ExecuteNonQuery();

                my_con.Close();

                SelectProduct();
                MessageBox.Show("Your Product Successfully Edited", "Congrats", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                txtFilterName.Text = "";
                txtQuantity.Text = "";
                textFilterPrice.Text = "";
                comboBrand.Text = "";
                
            }
        }

        private void btnDlt_Click(object sender, EventArgs e)
        {
            if (txtFilterID.Text == "" && txtFilterName.Text == "" && txtQuantity.Text == "" && textFilterPrice.Text == "" && comboBrand.Text == "")
            {
                MessageBox.Show("Please select A row for Delete", "Stop", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                DataGridViewRow row = ProductGridView.SelectedRows[0];
                OleDbConnection my_con = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=MadinaFilter2 .accdb");
                my_con.Open();

                OleDbCommand command = new OleDbCommand("Delete From Producttbl where FilterID = " + row.Cells["FilterID"].Value.ToString(), my_con);

                command.ExecuteNonQuery();

                my_con.Close();

                SelectProduct();
                MessageBox.Show("Your Product Successfully Deleted","Congrats", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                txtFilterName.Text = "";
                txtQuantity.Text = "";
                textFilterPrice.Text = "";
                comboBrand.Text = "";
                txtFilterID.Text = "";
            }
        }

        private void ProductGridView_SelectionChanged(object sender, EventArgs e)
        {
            if (ProductGridView.SelectedRows.Count != 0)
            {
                DataGridViewRow row = ProductGridView.SelectedRows[0];
                txtFilterName.Text = row.Cells["FilterName"].Value.ToString();
                txtQuantity.Text = row.Cells["Quantity"].Value.ToString();
                comboBrand.Text = row.Cells["Brand"].Value.ToString();
                textFilterPrice.Text = row.Cells["FilterPrice"].Value.ToString();
                txtFilterID.Text = row.Cells["FilterID"].Value.ToString();
            }

        }
    }
}
