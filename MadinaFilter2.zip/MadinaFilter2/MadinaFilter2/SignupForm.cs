﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MadinaFilter2
{
    public partial class SignupForm : Form
    {
        public SignupForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textusername.Text == "" && textpassword.Text == "" && textconfirmpassword.Text == "")
            {
                MessageBox.Show("Please Enter User Name And Password And Confirm Password", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (textusername.Text == "" && textpassword.Text == "")
            {
                MessageBox.Show("Please Enter User Name And Password", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textconfirmpassword.Text = "";
            }
            else if (textusername.Text == "" && textconfirmpassword.Text == "")
            {
                MessageBox.Show("Please Enter User Name And Confirm Password", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textpassword.Text = "";
            }
            else if (textpassword.Text == "" && textconfirmpassword.Text == "")
            {
                MessageBox.Show("Please Enter Password And Confirm Password", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textusername.Text = "";
            }
            else if (textusername.Text == "")
            {
                MessageBox.Show("Please Enter User Name ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textpassword.Text = "";
                textconfirmpassword.Text = "";
            }
            else if (textpassword.Text == "")
            {
                MessageBox.Show("Please Enter Password ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textusername.Text = "";
                textconfirmpassword.Text = "";
            }
            else if (textconfirmpassword.Text == "")
            {
                MessageBox.Show("Please Enter Confirm Password ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textusername.Text = "";
                textpassword.Text = "";
            }
            else if (textpassword.Text == textconfirmpassword.Text)
            {
                OleDbConnection my_con = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=MadinaFilter2 .accdb");
                my_con.Open();
                OleDbCommand command = new OleDbCommand("Insert into usertbl (UserName,UserPassword) Values('" + textusername.Text + "','" + textpassword.Text + "')", my_con);
                command.ExecuteNonQuery();

                my_con.Close();
                textusername.Text = "";
                textpassword.Text = "";
                textconfirmpassword.Text = "";
                MessageBox.Show("Your Account Successfully Signup","Congrats", MessageBoxButtons.OK,MessageBoxIcon.Asterisk);
            }
            else
            {
                MessageBox.Show("Password Does Not Matched , Please Re-Enter The Password", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textpassword.Text = "";
                textconfirmpassword.Text = "";
             }
                                    
        }

        private void checkBoxshowpass_CheckedChanged(object sender, EventArgs e)
        {

            if (checkBoxshowpass.Checked)
            {
                textpassword.PasswordChar = '\0';
                textconfirmpassword.PasswordChar = '\0';
            }
            else
            {
                textpassword.PasswordChar = '*';
                textconfirmpassword.PasswordChar = '*';
            } 
                         
        }

        private void label5_Click(object sender, EventArgs e)
        {
            this.Hide();
            LoginForm login = new LoginForm();
            login.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
